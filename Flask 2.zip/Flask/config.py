class ProjectConfig:
    DEBUG = True  # Active le mode débogage
    SECRET_KEY = 'votre_clé_secrète_du_projet'
    # Autres configurations globales...
