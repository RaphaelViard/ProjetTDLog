from app import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    author = db.Column(db.String(255), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    content = db.Column(db.Text, nullable=False)
    rating = db.Column(db.Float, nullable=False)
    date = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    likes = db.Column(db.Integer, default=0, nullable=False)
    statereply = db.Column(db.Integer, default=0, nullable=False)
    replies = db.relationship(
        'Comment',
        back_populates='parent_comment',
        cascade='all, delete-orphan',
        single_parent=True  # Ajoutez cette ligne
    )
    parent_comment_id = db.Column(db.Integer, db.ForeignKey('comment.id'))
    parent_comment = db.relationship('Comment', back_populates='replies', remote_side=[id])
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'))
    event = db.relationship('Event', back_populates='comments')

class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    duration = db.Column(db.Float, nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    dates = db.relationship('DateEvent', secondary='date_event_association', back_populates='events')
    place_id = db.Column(db.Integer, db.ForeignKey('place.id'))
    category = db.Column(db.String(255))
    image = db.Column(db.String(255))
    info = db.Column(db.Text)
    place = db.relationship('Place', back_populates='events')
    tickets = db.relationship('Ticket', back_populates='event', cascade='all, delete-orphan')
    comments = db.relationship('Comment', back_populates='event', cascade='all, delete-orphan')
    event_dates = db.relationship('DateEvent', secondary='date_event_association', back_populates='events')

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    password = db.Column(db.String, nullable=False)
    username = db.Column(db.String, nullable=False, unique=True)
    email = db.Column(db.String, unique=True)
    solde = db.Column(db.Float, default=0)
    color = db.Column(db.String, default="BLACK")
    image = db.Column(db.String)
    bio = db.Column(db.String)
    tickets_to_sale = db.relationship('Ticket', back_populates='seller', lazy='dynamic')
    transaction_history = db.relationship('Transaction', back_populates='seller', lazy='dynamic')
    comments = db.relationship('Comment', back_populates='user', lazy='dynamic')
    followers = db.relationship('User', back_populates='following', lazy='dynamic')
    following = db.relationship('User', secondary='followers', back_populates='followers', lazy='dynamic')

    def check_password(self, password):
        return check_password_hash(self.password, password)

    def set_password(self, password):
        self.password = generate_password_hash(password)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class IndividualUser(User):
    id = db.Column(db.Integer, db.ForeignKey('user.id'), primary_key=True)
    tickets_owned = db.relationship('Ticket', back_populates='owner', lazy='dynamic')
    event_interested = db.relationship('Event', secondary='user_event_interests', back_populates='interested_users', lazy='dynamic')

class Place(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    place = db.Column(db.String(100), nullable=False, unique=True)
    events = db.relationship('Event', secondary='place_event_association', back_populates='place')

place_event_association = db.Table(
    'place_event_association',
    db.Column('place_id', db.Integer, db.ForeignKey('place.id')),
    db.Column('event_id', db.Integer, db.ForeignKey('event.id'))
)

class Date(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.String(10), nullable=False)
    hour = db.Column(db.String(5))

class DateEvent(Date):
    id = db.Column(db.Integer, db.ForeignKey('date.id'), primary_key=True)
    events = db.relationship('Event', secondary='date_event_association', back_populates='event_dates')

date_event_association = db.Table(
    'date_event_association',
    db.Column('date_id', db.Integer, db.ForeignKey('date.id')),
    db.Column('event_id', db.Integer, db.ForeignKey('event.id'))
)

class Ticket(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    price = db.Column(db.Float, nullable=False)
    availability = db.Column(db.Boolean, default=True)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'))
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    event = db.relationship('Event', back_populates='tickets')
    owner = db.relationship('User', back_populates='tickets_owned')

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    buyer_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    price = db.Column(db.Float, nullable=False)
    ticket_id = db.Column(db.Integer, db.ForeignKey('ticket.id'))
    seller = db.relationship('User', foreign_keys=[seller_id])
    buyer = db.relationship('User', foreign_keys=[buyer_id])
    ticket = db.relationship('Ticket', back_populates='transactions')

