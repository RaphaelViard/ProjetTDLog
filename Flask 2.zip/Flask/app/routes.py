from flask import render_template, request, redirect, url_for, flash
from app import db, create_app
from app.models import User, Event  # and other models as needed
from app.forms import LoginForm, RegistrationForm
from flask_login import login_user, logout_user, login_required, current_user

app = create_app()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/onglet1', methods=['GET', 'POST'])
def onglet1():
    search_results = None

    if request.method == 'GET':
        query = request.args.get('query')
        if query:
            # Recherche d'événements par nom ou lieu
            search_results = Event.query.filter((Event.name.ilike(f"%{query}%")) | (Event.place.place.ilike(f"%{query}%"))).all()

    return render_template('onglet1.html', search_results=search_results)

@app.route('/onglet2')
def onglet2():
    return render_template('onglet2.html')

@app.route('/onglet3')
@login_required
def onglet3():
    return render_template('onglet3.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=True)  # Optionally add 'remember' functionality
            flash('Connexion réussie!', 'success')
            return redirect(url_for('onglet3'))
        else:
            flash('Échec de la connexion. Vérifiez votre nom d\'utilisateur et votre mot de passe.', 'danger')

    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)  # Assuming email field is included
        user.set_password(form.password.data)

        db.session.add(user)
        db.session.commit()

        flash('Inscription réussie! Vous pouvez maintenant vous connecter.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))
